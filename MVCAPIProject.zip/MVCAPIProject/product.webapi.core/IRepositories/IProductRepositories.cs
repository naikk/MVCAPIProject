﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace product.webapi.core
{
   public interface IProductRepositories
    {
       List<Product> GetAllProducts();
    }
}
