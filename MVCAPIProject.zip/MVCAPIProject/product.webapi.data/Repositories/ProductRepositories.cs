﻿using product.webapi.core;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace product.webapi.data
{
    public class ProductRepositories : IProductRepositories
    {
        public List<Product> Products;

        public ProductRepositories()
        {
            Products = new List<Product>();
            Products.Add(new Product() { ID = 1, ItemName = "Item1", Qty = 1, Amount = 10 });
            Products.Add(new Product() { ID = 2, ItemName = "Item2", Qty = 2, Amount = 20 });
            Products.Add(new Product() { ID = 3, ItemName = "Item3", Qty = 1, Amount = 10 });
            Products.Add(new Product() { ID = 4, ItemName = "Item4", Qty = 3, Amount = 30 });     
        }

        List<Product> IProductRepositories.GetAllProducts()
        {
            return Products;
        }
    }
}
 