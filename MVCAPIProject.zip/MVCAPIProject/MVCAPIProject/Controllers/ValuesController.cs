﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using product.webapi.core;

//using MVCAPIProject.Models;

namespace MVCAPIProject.Controllers
{
    public class ValuesController : ApiController
    {
        // GET api/values

       //public static List<Product> Products;
       

       //     static ValuesController() 
       // {
       //    // List<Product> Products;
       //        Products = new List<Product>();       
       //        Products.Add(new Product(){ID =1, ItemName ="Item1", Qty=1, Amount =10});
       //        Products.Add(new Product(){ID =2, ItemName ="Item2", Qty=2, Amount =20});
       //        Products.Add(new Product(){ID =3, ItemName ="Item3", Qty=1, Amount =10});
       //        Products.Add(new Product(){ID =4, ItemName ="Item4", Qty=3, Amount =30});     
       // }  

        public IProductRepositories _productRepositories;

        public ValuesController(IProductRepositories productRepositories)
        {
            _productRepositories = productRepositories;
        }
        
        public IEnumerable<Product> Get()
        {
            return _productRepositories.GetAllProducts();
        }

        // GET api/values/5
        public Product Get(int id)
        {
            //Product prod;
            //return  prod = Products.Where(x => x.ID == id).FirstOrDefault() ;
            return null;
        }

        // POST api/values
        public void Post([FromBody]Product value)
        {
            //Products.Add(new Product() { ID = value.ID, ItemName = value.ItemName, Qty = value.Qty, Amount = value.Amount });

        }

        // PUT api/values/5
        public void Put(int id, [FromBody]string value)
        {
        }

        // DELETE api/values/5
        public void Delete(int id)
        {
        }
    }
}
